"""
hints.py
--------
Encapsulates hint logic so the Game class doesn't need to track
hint counts itself. Separating this makes it easy to later add
things like "buy an extra hint with points" without touching Game.
"""


class HintManager:
    """Tracks how many hints a player has left in the current round."""

    def __init__(self, max_hints):
        self.max_hints = max_hints
        self.hints_used = 0

    @property
    def hints_left(self):
        return self.max_hints - self.hints_used

    def use_hint(self):
        """
        Consume one hint if available.
        Returns True if a hint was successfully used, False if none left.
        """
        if self.hints_left <= 0:
            return False
        self.hints_used += 1
        return True

    def any_hint_used(self):
        return self.hints_used > 0
