"""
main.py
-------
Entry point for the OOP Advanced Hangman game. Handles the menu flow
(category/difficulty selection, guess loop, replay) and delegates all
game state to the Game class, score persistence to Scoreboard, and
player stats to Player.

Run with:
    python main.py
"""

from words import WordBank
from game import Game
from player import Player
from scoreboard import Scoreboard
from utils import DIFFICULTY_SETTINGS, prompt_choice, prompt_menu_index


def choose_category():
    print("\nChoose a category:")
    return prompt_menu_index("Enter choice number: ", WordBank.categories())


def choose_difficulty():
    print("\nChoose a difficulty:")
    print("  1. Easy   (8 wrong guesses, 3 hints)")
    print("  2. Medium (6 wrong guesses, 2 hints)")
    print("  3. Hard   (4 wrong guesses, 1 hint)")
    key = prompt_choice("Enter choice number: ", DIFFICULTY_SETTINGS)
    return DIFFICULTY_SETTINGS[key]


def get_guess(game):
    """Prompt for a single letter guess or 'h' for a hint. Returns the letter or 'HINT'."""
    while True:
        raw = input("\nGuess a letter (or 'h' for a hint): ").strip().lower()

        if raw == "h":
            if game.hint_manager.hints_left > 0:
                return "HINT"
            print("No hints left!")
            continue

        if len(raw) != 1 or not raw.isalpha():
            print("Please enter a single valid letter.")
            continue

        if raw in game.guessed_letters:
            print("You already guessed that letter.")
            continue

        return raw


def play_round(player, scoreboard):
    """Run one full round of Hangman using the Game class. Updates player/scoreboard."""
    category = choose_category()
    difficulty = choose_difficulty()
    game = Game(category, difficulty)

    print(f"\nCategory: {category} | Difficulty: {difficulty['label']}")
    print(f"The word has {len(game.word)} letters.")

    while not game.is_won and not game.is_lost:
        print(game.render_board())
        guess = get_guess(game)

        if guess == "HINT":
            hint_text = game.get_hint()
            print(f"\nHint: {hint_text}")
            continue

        correct = game.guess_letter(guess)
        print("Good guess!" if correct else f"Wrong! '{guess}' is not in the word.")

    if game.is_won:
        points = game.calculate_points()
        player.add_points(points)
        player.record_round(won=True)
        print(f"\nYou guessed it! The word was '{game.word}'.")
        print(f"You earned {points} points! Total score: {player.score}")
        if scoreboard.update_if_higher(player.score):
            print("New high score!")
    else:
        player.record_round(won=False)
        print(game.render_board())
        print(f"\nGame over! The word was '{game.word}'.")


def main():
    print("=" * 50)
    print("        WELCOME TO ADVANCED HANGMAN (OOP Edition)")
    print("=" * 50)

    name = input("Enter your name: ").strip() or "Player"
    player = Player(name)
    scoreboard = Scoreboard()

    print(f"\nHi {player.name}! Current high score: {scoreboard.load_high_score()}")

    while True:
        play_round(player, scoreboard)
        print(f"\n{player.summary()}")

        again = input("\nPlay another round? (y/n): ").strip().lower()
        if again != "y":
            break

    print(f"\nFinal {player.summary()}")
    print(f"High score: {scoreboard.load_high_score()}")
    print("Thanks for playing! Goodbye.")


if __name__ == "__main__":
    main()
