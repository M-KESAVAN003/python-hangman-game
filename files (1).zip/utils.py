"""
utils.py
--------
Shared helper functions and constants that don't belong to a single
class: ASCII art stages, difficulty settings, and small I/O helpers.
"""

HANGMAN_STAGES = [
    r"""
       ------
       |    |
       |
       |
       |
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |
       |
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |    |
       |
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |   /|
       |
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |   /|\
       |
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |   /|\
       |   /
       |
    ---------
    """,
    r"""
       ------
       |    |
       |    O
       |   /|\
       |   / \
       |
    ---------
    """,
]

DIFFICULTY_SETTINGS = {
    "1": {"label": "Easy", "max_wrong": 8, "hints": 3},
    "2": {"label": "Medium", "max_wrong": 6, "hints": 2},
    "3": {"label": "Hard", "max_wrong": 4, "hints": 1},
}


def display_word(word, guessed_letters):
    """Return the word with unguessed letters replaced by underscores."""
    return " ".join(letter if letter in guessed_letters else "_" for letter in word)


def prompt_choice(prompt_text, valid_options):
    """Repeatedly prompt until the user enters one of the valid_options keys."""
    while True:
        choice = input(prompt_text).strip()
        if choice in valid_options:
            return choice
        print("Invalid choice. Please try again.")


def prompt_menu_index(prompt_text, options_list):
    """Display a numbered list and return the chosen item from options_list."""
    for idx, option in enumerate(options_list, start=1):
        print(f"  {idx}. {option}")
    while True:
        choice = input(prompt_text).strip()
        if choice.isdigit() and 1 <= int(choice) <= len(options_list):
            return options_list[int(choice) - 1]
        print("Invalid choice. Please try again.")
