# Advanced Hangman — OOP Edition

This is Step 2 of a multi-stage project: converting a basic console Hangman game into a clean, object-oriented structure. This foundation is what later steps (SQLite, leaderboard, Tkinter GUI, login system) will build on top of.

## Why OOP here?

Each responsibility is isolated into its own class/module, so future features can be added without rewriting existing code:

| Module | Responsibility |
|---|---|
| `words.py` | `WordBank` — stores categories, words, hints; picks random words |
| `hints.py` | `HintManager` — tracks hint usage per round |
| `player.py` | `Player` — tracks name, score, round history, win rate |
| `game.py` | `Game` — core round logic: guessing, win/loss state, scoring |
| `scoreboard.py` | `Scoreboard` — saves/loads high score (JSON now, SQLite later) |
| `utils.py` | Shared constants (ASCII art, difficulty settings) and small I/O helpers |
| `main.py` | Entry point — menu flow, wires all classes together |

## How to Run

```bash
python main.py
```

No external dependencies — pure Python standard library.

## How to Play

1. Enter your name
2. Choose a category (Programming, Animals, Countries, Movies)
3. Choose a difficulty (Easy / Medium / Hard)
4. Guess letters one at a time, or type `h` for a hint (limited uses)
5. Win before running out of attempts to earn points
6. Play multiple rounds — your score and win rate are tracked per session
7. Beat the saved high score to set a new record

## Project Structure

```
hangman-oop/
├── main.py           # Entry point / menu flow
├── game.py           # Game class (core round logic)
├── player.py         # Player class (score, stats)
├── words.py          # WordBank class (categories, words, hints)
├── hints.py           # HintManager class
├── scoreboard.py      # High score persistence (JSON for now)
├── utils.py           # ASCII art, difficulty settings, I/O helpers
├── data/
│   └── scores.json     # Auto-generated high score file
└── README.md
```

## Roadmap (Next Steps)

- [x] Step 1: Basic console Hangman
- [x] Step 2: OOP refactor *(this version)*
- [ ] Step 3: Add richer scoring, achievements, word statistics
- [ ] Step 4: Swap JSON scoreboard for SQLite; add a `Database` class and multi-player leaderboard
- [ ] Step 5: Build a Tkinter GUI on top of the same `Game`/`Player`/`WordBank` classes
- [ ] Step 6: Add login/profiles, sound effects, admin panel for managing words

## Author

Chellam
