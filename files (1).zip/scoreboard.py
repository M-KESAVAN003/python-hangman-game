"""
scoreboard.py
-------------
Handles saving/loading high scores. Currently backed by a JSON file
under data/. In a later step this gets swapped for SQLite without
changing how Game/main.py call it — that's the point of isolating it
in its own class.
"""

import json
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
SCORES_FILE = os.path.join(DATA_DIR, "scores.json")


class Scoreboard:
    """Reads and writes high scores to a local JSON file."""

    def __init__(self, filepath=SCORES_FILE):
        self.filepath = filepath
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)

    def load_high_score(self):
        if not os.path.exists(self.filepath):
            return 0
        try:
            with open(self.filepath, "r") as f:
                data = json.load(f)
                return data.get("high_score", 0)
        except (json.JSONDecodeError, IOError):
            return 0

    def save_high_score(self, score):
        with open(self.filepath, "w") as f:
            json.dump({"high_score": score}, f)

    def update_if_higher(self, score):
        """Save the score only if it beats the current high score. Returns True if updated."""
        current = self.load_high_score()
        if score > current:
            self.save_high_score(score)
            return True
        return False
