"""
game.py
-------
The Game class encapsulates a single round of Hangman: picking a word,
tracking guesses, and scoring. It depends on WordBank, HintManager,
and the shared display helpers in utils.py, but knows nothing about
menus or I/O beyond simple input()/print() — that keeps it easy to
later swap in a Tkinter GUI without rewriting this logic.
"""

from words import WordBank
from hints import HintManager
from utils import HANGMAN_STAGES, display_word


class Game:
    """Represents one playable round of Hangman."""

    def __init__(self, category, difficulty):
        self.category = category
        self.difficulty = difficulty
        self.word, self.hint = WordBank.random_word(category)
        self.guessed_letters = set()
        self.wrong_guesses = 0
        self.max_wrong = difficulty["max_wrong"]
        self.hint_manager = HintManager(difficulty["hints"])

    @property
    def is_won(self):
        return all(letter in self.guessed_letters for letter in self.word)

    @property
    def is_lost(self):
        return self.wrong_guesses >= self.max_wrong

    def get_hint(self):
        """Attempt to use a hint. Returns the hint text or None if unavailable."""
        if self.hint_manager.use_hint():
            return self.hint
        return None

    def guess_letter(self, letter):
        """
        Register a letter guess. Returns True if correct, False if wrong.
        Assumes the letter hasn't been guessed before (caller should check).
        """
        self.guessed_letters.add(letter)
        if letter in self.word:
            return True
        self.wrong_guesses += 1
        return False

    def calculate_points(self):
        """Compute points earned for winning this round."""
        points = self.max_wrong * 10 - self.wrong_guesses * 5
        if self.hint_manager.any_hint_used():
            points = points // 2
        return max(points, 5)

    def render_board(self):
        """Return a printable string of the current game state."""
        stage = HANGMAN_STAGES[min(self.wrong_guesses, len(HANGMAN_STAGES) - 1)]
        word_display = display_word(self.word, self.guessed_letters)
        guessed = ", ".join(sorted(self.guessed_letters)) or "None"
        return (
            f"{stage}\n"
            f"Word: {word_display}\n"
            f"Wrong guesses: {self.wrong_guesses}/{self.max_wrong}\n"
            f"Guessed letters: {guessed}\n"
            f"Hints left: {self.hint_manager.hints_left}"
        )
