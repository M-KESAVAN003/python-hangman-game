"""
player.py
---------
Represents a player and their session data (name, score, round history).
Later steps (SQLite, login) will extend this class to persist across
sessions instead of just living in memory.
"""


class Player:
    """Holds a player's name, running score, and round history."""

    def __init__(self, name="Player"):
        self.name = name
        self.score = 0
        self.rounds_played = 0
        self.rounds_won = 0

    def add_points(self, points):
        self.score += points

    def record_round(self, won):
        self.rounds_played += 1
        if won:
            self.rounds_won += 1

    @property
    def win_rate(self):
        if self.rounds_played == 0:
            return 0.0
        return round((self.rounds_won / self.rounds_played) * 100, 1)

    def summary(self):
        return (
            f"Player: {self.name} | Score: {self.score} | "
            f"Rounds: {self.rounds_played} | Wins: {self.rounds_won} | "
            f"Win rate: {self.win_rate}%"
        )
