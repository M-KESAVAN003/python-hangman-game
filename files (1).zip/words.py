"""
words.py
--------
Holds the word bank and provides a WordBank class to fetch random
words and hints by category. Keeping this in its own module means
adding new categories/words later doesn't touch any game logic.
"""

import random


class WordBank:
    """Manages categorized words and their hints."""

    _DATA = {
        "Programming": {
            "python": "A popular high-level programming language named after a snake.",
            "variable": "A container used to store data values.",
            "function": "A reusable block of code that performs a task.",
            "algorithm": "A step-by-step procedure for solving a problem.",
            "compiler": "A program that translates source code into machine code.",
        },
        "Animals": {
            "elephant": "The largest land animal, known for its trunk.",
            "giraffe": "The tallest living terrestrial animal.",
            "dolphin": "A highly intelligent marine mammal.",
            "kangaroo": "An animal native to Australia that hops.",
            "penguin": "A flightless bird that lives in cold climates.",
        },
        "Countries": {
            "india": "Home to the Taj Mahal, in South Asia.",
            "japan": "Known as the Land of the Rising Sun.",
            "brazil": "The largest country in South America.",
            "canada": "Known for maple syrup and cold winters.",
            "egypt": "Home to the ancient pyramids.",
        },
        "Movies": {
            "inception": "A movie about entering dreams within dreams.",
            "titanic": "A movie about a famous ship disaster.",
            "avatar": "A movie set on the planet Pandora.",
            "gladiator": "A movie about a Roman general turned slave.",
            "interstellar": "A movie about space travel to save humanity.",
        },
    }

    @classmethod
    def categories(cls):
        """Return a list of available category names."""
        return list(cls._DATA.keys())

    @classmethod
    def random_word(cls, category):
        """Return a (word, hint) tuple randomly chosen from the given category."""
        if category not in cls._DATA:
            raise ValueError(f"Unknown category: {category}")
        word, hint = random.choice(list(cls._DATA[category].items()))
        return word, hint
